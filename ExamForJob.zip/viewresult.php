<?php include("segment/header.php");?>
<?php include("classes/loginclass.php");

Session::checkSession();

 $ob=new Database();
?>
<?php 
if(isset($_GET['logout'])&&$_GET['logout']=='logout'){
   Session::destroy();
   header('Location:index.php');
   
}
?>
<?php 
if(isset($_POST['submit'])){
    $subject=$_POST['subject'];
 $query="SELECT distinct model,topics From questions WHERE subject1='$subject'";
 $result=$ob->select($query);

}
?>
<div class="container-fluid" >
  <div class="jumbotron">
     <h2 style="text-align:center;font-family:'Acme';color:#007a7e;"><a href="home.php" style="text-align: center;color: #208669;font-weight: 600; text-shadow: 0px 1px #152c44;text-decoration-line:none">Welcome To Govt. Job Study Group</a>  </h2> 
  
    <h3  style="text-align:center;font-family:'Acme';color:#007a7e;">MCQ Exam System</h3>
  </div>
  
</div>
<div class="container-fluid" >
	<div class="row">
	
			<div class="col-md-12  ">
        <!-- modal start  -->
        
        <!-- modal end -->
                <h2 style="text-align: center;
text-shadow: 1px 2px #88919b;
font-family: bold;
font-weight: 700;">Search Result
<?php if(isset($subject)){echo "(" .$subject.")";}
 ?></h2>
<!--<embed src="pdf/taker.pdf" type="application/pdf" width="100%" height="600px" style="margin:0 auto,display:block" />-->
       <div class="container">
           <?php //if(isset($result)){ ?>
  <form action="" method="post">
    <div class="form-group">
    <select class="form-control" name="subject" aria-label="Default select example">
  <option selected>Select Subject</option>
  <option value="Bangla">Bangla</option>
  <option value="English">English</option>
  <option value="Mathematics">Mathematics</option>
    <option value="Computer">Computer</option>
  <option value="Bangladesh Affairs">Bangladesh Affairs</option>
  <option value="Mental Ability">Mental Ability</option>
    <option value="Science">Science</option>
  <option value="International Affairs">International Affairs</option>
  <option value="Geography">Geography</option>
    <option value="IT">IT</option>
  
</select>
    </div>

    <button type="submit" name="submit" class="btn btn-primary">Submit</button>
  </form>
  <?php //}?>
  <div class="row">
      
  <?php
  if(isset($result)){
      while($row=$result->fetch_assoc()){
        

  ?>
  <div class="col-md-3" style="background:#456;color:white;margin-top:4px;margin-bottom:3px;margin-left:2px;margin-right:2px
 ; padding:8px">
  <a href="Result.php?subject=<?php echo $subject?> &model=<?php echo $row['model'];?>" style="color:white;padding:4px">Model Test:<?php echo $row['model']; ?> <br>Topics:<?php echo $row['topics']; ?></a><br>
  </div>
  <?php       } }?>

  </div>
</div>       
      </div>

    
				
	</div>


</div>
</div>
</div>


<?php include("segment/footer.php");?>