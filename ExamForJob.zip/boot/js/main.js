    <script type="text/javascript">
                      $(document).ready(function(){
                          $("#tab").click(function(){
                                $("#myModal").modal();
                          });
                      });
                    </script>






