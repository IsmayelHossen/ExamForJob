<?php include("segment/header.php");?>
<?php include("classes/loginclass.php");

Session::checkSession();

 $ob=new login();

 if(isset($_POST['roll'])){
 	$roll=$_POST['roll'];
 	  Session::set("roll",$roll);
 	$result=$ob->subjectget($roll);
 	
 }



 ?>