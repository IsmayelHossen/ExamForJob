<?php include("segment/header.php");?>
<?php include("classes/loginclass.php");

Session::checkSession();

 $db=new Database();
?>
<?php 
if(isset($_GET['logout'])&&$_GET['logout']=='logout'){
   Session::destroy();
   header('Location:index.php');
   
}
?>

<div class="container-fluid" >
  <div class="jumbotron">
     <h2 style="text-align:center;font-family:'Acme';color:#007a7e;"><a href="home.php" style="text-align: center;color: #208669;font-weight: 600; text-shadow: 0px 1px #152c44;text-decoration-line:none">Welcome To Govt. Job Study Group</a>  </h2> 
  
    <h3  style="text-align:center;font-family:'Acme';color:#007a7e;">MCQ Exam System</h3>
  </div>
  
</div>
<div class="container-fluid" >
	<div class="row">
	
			<div class="col-md-12  ">
           <!-- Highest mark Calculation -->
      <h3 style="text-align: center;color: #208669;font-weight: 600; text-shadow: 0px 1px #152c44;">All Participators Result
      (<?php echo $_GET['subject']?>)</h3>
      <?php
       $cate=$_GET['subject'];
      $model=$_GET['model'];
       $query12="SELECT DISTINCT email FROM questions WHERE  subject1='$cate' AND model='$model' ";
		    $maker=$db->select($query12);
		    $examTaker=$maker->fetch_assoc();
		    $Taker=$examTaker['email'];
      $query="SELECT DISTINCT email FROM examinee_ans WHERE  subject1='$cate' AND model='$model' ";
		    $get_heighest=$db->select($query);?>
		  <h4 style="color: #ee6d0f;text-align: center;padding: 10px;">Exam Taker: <?php echo $Taker; ?></h4> 
      <div class="table-responsive"><table class="table table-striped">
         
      <thead>
        <tr>
        <th scope="col">Email</th>
          <th scope="col">Correct Answer</th>
          <th scope="col">Wrong Answer</th>
         
          <th scope="col">Score</th>
            <th scope="col">View</th>
            <th>Submitted Time</th>
        </tr>
      </thead>
      <tbody>
          <?php
      if($get_heighest){
          $subject=$_GET['subject'];
          $model=$_GET['model'];
        while($rowParent=$get_heighest->fetch_assoc()){
          //again query start
          $rand=(rand(10,100));
          $email=$rowParent['email'];
          $query="SELECT DISTINCT examinee_ans.ques_no, examinee_ans.ans1,questions.ans,questions.question,examinee_ans.time1,questions.email FROM examinee_ans INNER JOIN questions
		ON examinee_ans.ques_no=questions.ques_no WHERE examinee_ans.email='$email'  AND examinee_ans.subject1='$subject' AND examinee_ans.model=$model AND questions.model=$model AND questions.subject1='$subject'   ";
//$query="SELECT*FROM examinee_ans WHERE email='$email' AND subject1='$subject' AND model='$model' ";
		    $GetForHeighestMark=$db->select($query);
          
       if($GetForHeighestMark){
        $no=0;
        $right=0;
        $wrong=0;
       
        while($row=$GetForHeighestMark->fetch_assoc()){
          //  $no=1;
              if($row['ans']==$row['ans1']){
                  $right++;
                  $no++;
                
              }
              else{
                $wrong++;
                $no++;

              }
          $DateTime=$row['time1'];
           $ExamTaker=$row['email'];
           }
        
          }

 //again query end
     $email=$_SESSION["email"];
             $subject=$_GET['subject'];
    $model=$_GET['model'];
    $query="SELECT*FROM timeMarks WHERE subject1='$subject' AND model=$model";
    $result=$db->select($query);
       $row12=$result->fetch_assoc();
$Score=$right*1-$wrong*$row12['cutmark'];
//print inividual result

//echo "Email:".$rowParent['email']."Wrong=".$wrong."Rright=".$right."<br>";
?>
 <tr>
<td><?php echo$rowParent['email']?></td>
<td><?php echo$right?></td>
<td><?php echo $wrong?></td>
<td><?php echo $Score?></td>
<td>

<!-- Modal start -->
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal<?php echo$rand?>">view</button>

<!-- Modal -->
<div id="myModal<?php echo$rand?>" class="modal fade" role="dialog">
  <div class="modal-dialog  modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
         
      </div>
      <div class="modal-body">
      <h4 class="modal-title" style="color: red;text-align: center;font-weight: bold">All Wrong Answer</h4>
    <h5 style=" font-weight: bold;color: #21824b;">Examinee:<?php echo$rowParent['email']?></h5>
            
            <?php
             $email=$rowParent['email'];
          $query="SELECT DISTINCT examinee_ans.ques_no, examinee_ans.ans1,questions.ans,questions.question FROM examinee_ans INNER JOIN questions
		ON examinee_ans.ques_no=questions.ques_no WHERE examinee_ans.email='$email'  AND examinee_ans.subject1='$subject' AND examinee_ans.model=$model AND questions.model=$model AND questions.subject1='$subject'   ";
//$query="SELECT*FROM examinee_ans WHERE email='$email' AND subject1='$subject' AND model='$model' ";
		    $GetForHeighestMark=$db->select($query);
            $count=mysqli_num_rows($GetForHeighestMark);
              if($count>0){
        $no=0;
        $right=0;
        $wrong=0;
       
        while($row2=$GetForHeighestMark->fetch_assoc()){
          //  $no=1;
              if($row2['ans']!=$row2['ans1']){
                  $right++;
                  $no++;
                  $wrong++;
                  ?>
                 <h5
                 style="   background: #dbe7f2;color: #090e13;padding: 4px;margin-top: 0px;margin-bottom: 0px; " >
                     <?php echo $row2['ques_no']; ?>:<?php echo $row2['question']; ?></h5>
                 <p style="color:red ;margin-top: 0px;margin-bottom: 0rem;padding: 0px;">Selected:<?php echo $row2['ans1']; ?></p>
                  <p style="color:green;margin-top: 0px;margin-bottom: 0rem;padding: 0px;">Correct:<?php echo $row2['ans']; ?></p>
                  <hr>
            <?php
            } } }
            if($wrong==0){
                echo "<h6 style='color: #aa3232;'>Congratulations! You Have Got Score Without Negative Marks!!!!</h6>";
            }
            ?>
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


<!-- Modal end -->

</td>
<td><?php echo$DateTime?></td>

</tr>
  <?php }

      ?>
  </tbody>
  </table></div>

      <?php }

      ?>
           

</div>       
      </div>

    
				
	</div>


</div>
</div>
</div>


<?php include("segment/footer.php");?>