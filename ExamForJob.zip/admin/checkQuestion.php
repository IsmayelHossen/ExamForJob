<?php 
  session_start();
  if($_SESSION["login"]==false){
      echo"<script>window:location='index.php'</script>";
      
  }?>
  <?php  if(isset($_GET['action']) && $_GET['action']=="logout")
                             
                               echo"<script>window:location='index.php'</script>";
?>
<?php
    $msg=" ";
   
     include("database/Connection.php");
     include("database/Formet.php");
      $db = new Database();
      $fm=new Format();
?>
         <?php
                   if(isset($_GET["delete"]))
                   {
                      $model=$_GET["delete"];
                     // $subject=Session::get("subject");
                       $email=$_SESSION["email"];
                      $subject=$_SESSION["subject"];
                   
                      $query4="DELETE FROM questions WHERE model='$model'AND subject1='$subject' ";
                      $result4=$db->delete($query4);
                      $query5="DELETE FROM timeMarks WHERE model='$model'AND subject1='$subject' ";
                      $result5=$db->delete($query5);
                    
                     if($result5){
                     $msg3="<div class='alert alert-success'><span>Successfully Deleted!</span></div>";


                  }
                   else{
                   $msg3="<div class='alert alert-danger'><span>Please Try Again!</span></div>";

                 }
               }

?>
<?php 
if(isset($_POST['submitSwitch'])){
    $switch1=$_POST['switch1'];
   // $subject= Session::get("subject");
            $email=$_SESSION["email"];
             $subject=$_SESSION["subject"];
    $model=$_POST['model'];
    $query="UPDATE questions SET active1=$switch1 WHERE subject1='$subject' AND model=$model AND email='$email'";
    $result=$db->update($query);
}?>
<!DOCTYPE html>
<html lang="en">
<head>
   <title>Exam For Job</title>
    <link rel="icon"  href="images/ictlogo.jpg">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="boot/css/bootstrap.css">

<script src="boot/js/jquery.js"></script>
<script type="text/javascript" src="boot/js/bootstrap.js"></script>
 
<script type="text/javascript" src="boot/js/main2.js"></script>

  <link rel="stylesheet" type="text/css" href="style.css">
 <meta http-equiv="content-type" content="text/html; charset=utf-8" />
<style type="text/css">
  body{
    font-family:'Acme';

  }
  label{
      font-size:20px;
  }
  .side ul li a{
                    text-decoration: none;
                  }
</style>
</head>
<body>

<div class="container-fluidh">
    <div class="Jumbotron">
          <h3> Welcome <?php echo $_SESSION["name"]; ?> To Exam For Job(Admin Panel) </h3>
    </div>

  </div>
  <div class="container-fluidm">
      <div class="row">
        <div class="col-md-3">
          <div class="side">
               <ul>
               
                <li>
                 <a href="home.php" >Dashbord(<?php echo$_SESSION['subject']; ?>)</a>
                  </li>
            <li> <a href="AllModelTest.php" style="text-decoration: none;" >All Model Test </a></li>
             <li> <a href="routine.php" style="text-decoration: none;" >Routine </a></li>
             <!-- <li> <a href="message.php" style="text-decoration: none;" >Messages </a></li> -->
        
         <li><a href="?action=logout" >Logout</a></li>
        </ul>


    </div>
  </div>
       <div class="col-md-9" style="margin-bottom:5em">
      
           <!-- Questions & right answer -->
    <div class="container-fluid" >
	<div class="row">
	<h3 style="text-align: center;color: #208669;font-weight: 600; text-shadow: 0px 1px #152c44;">Questions & Right Answers</h3>
			<div class="col-md-12">
        <form method="post" action="">
            <?php 
             if(isset($_GET['model'])){
               $i=0;
                  $subject=$_SESSION["subject"];
                 $model=$_GET['model'];
                 
              	$query="SELECT*FROM questions WHERE subject1='$subject' AND model=$model  ORDER BY ques_no ASC";
	   	 $result=$db->select($query);

                 if($result){
                     while($row= $result->fetch_assoc()){
                       $i++;

                   
            ?>
        <h4 style="font-size: 18px;background: #c2d0cc;padding: 9px 2px;"><?php echo $row['ques_no'] ?>. <?php echo $row['question'] ?> </h4>
          <?php if($row['image']){
            
            ?>
            <div style="max-width: 400px" >
                <img src="../admin/<?php echo $row['image'] ?>" style="margin-top:2px" width='200px;'>
            </div>
            <?php
        }
        ?>
       <ul>
           <li>
               <?php 
              //  if($row['ans1']==$row['ans']){ 
              //  echo '<h5 style="color:red">'.$row['ans'].'</h5>'; 
              //  }
               if($row['option1']==$row['ans']){
                echo '<h4 style="color:green"><strong>'.$row['ans'].'</strong></h4>'; 
               }
               else{
                     echo '<h5>'.$row['option1'].'</h5>'; 
               }
               ?>
           </li>
           
            <li>
               <?php 
               if($row['option2']==$row['ans']){ 
                echo '<h4 style="color:green"><strong>'.$row['ans'].'</strong></h4>'; 
               }
               else{
                     echo '<h5>'.$row['option2'].'</h5>'; 
               }
               ?>
           </li>
           
            <li>
               <?php 
               if($row['option3']==$row['ans']){ 
                echo '<h4 style="color:green"><strong>'.$row['ans'].'</strong></h4>';
               }
               else{
                     echo '<h5>'.$row['option3'].'</h5>'; 
               }
               ?>
           </li>
            <li>
               <?php 
               if($row['option4']==$row['ans']){ 
                echo '<h4 style="color:green"><strong>'.$row['ans'].'</strong></h4>';
               }
               else{
                     echo '<h5>'.$row['option4'].'</h5>'; 
               }
               ?>
           </li>
          
       </ul>

       <?php 
       
    }
}
}
?>

        </form>

      
      
			</div>
				
	</div>



</div>
</div>


</body>
</html>


