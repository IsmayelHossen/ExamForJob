<?php
define("DB_HOST", "localhost");
define("DB_USER", "id17224106_examforjob123");
define("DB_PASS", "45012@Ismayel");
define("DB_NAME", "id17224106_examforjob");

