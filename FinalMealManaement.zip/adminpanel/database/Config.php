<?php
define("DB_HOST", "localhost");
define("DB_USER", "id10041508_ismayel");
define("DB_PASS", "12345678");
define("DB_NAME", "id10041508_meal");

