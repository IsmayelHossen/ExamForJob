<?php
define("DB_HOST", "localhost");
define("DB_USER", "id10041508_ismayel");
define("DB_PASS", "45012ismayel");
define("DB_NAME", "id10041508_mm");

